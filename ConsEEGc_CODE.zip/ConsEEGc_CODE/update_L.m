function L_tp1=update_L(L_0,W_t,S_t,parameter)
[mS nS]=size(S_t);
[Lap D]=lapMatrix(S_t);

L_t=L_0;
t=1;
while t<parameter.iter+1
    P1=L_t*(parameter.gamma4*Lap+parameter.gamma2*eye(mS));
    P2=W_t'*S_t;
    for i=1:parameter.c
        P2(i,:)=P2(i,:)/sum(P2(i,:)); %W'S*1=1;
    end
    derL=P1-parameter.gamma2*P2;
    %derL=L_t*(parameter.gamma4*Lap+parameter.gamma2*ones(mS))-parameter.gamma2*W_t'*S_t; % derivative of L
    L_t=L_t-parameter.eta*derL;
    t=t+1;
end

L_tp1=L_t;

