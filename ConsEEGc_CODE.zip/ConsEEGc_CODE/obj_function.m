function Obj=obj_function(M,R,W,S,L_S,D_S,L,parameter)
part1=0.5*parameter.gamma1*trace((S-M)'*(S-M));
part2=0.5*parameter.gamma2*trace((W'*S-L)'*(W'*S-L));
part3=0.5*parameter.gamma3*trace(W'*W);
part4=0.5*parameter.gamma4*trace(L*L_S*L');
part5=0.5*parameter.gamma5*trace(R'*L_S*R);
Obj=part1+part2+part3+part4+part5;