function R_tp1=update_R(R_0,S_t,parameter)

[mS nS]=size(S_t);
[Lap D]=lapMatrix(S_t);
% 
% % [mS nS]=size(S);
% %------------------construct B-----------
% sen=zeros(mS,1);
% for t=1:parameter.c
%     for j=1:parameter.v
%         sen((mS/parameter.c*(t-1)+mS/(parameter.c*parameter.v)*(j-1)+1):(mS/parameter.c*(t-1)+mS/(parameter.c*parameter.v)*j))=j;
%     end
% end
% 
% sen_unique=unique(sen);
% v=length(sen_unique);
% sen_unique=reshape(sen_unique,[1, v]);
% senUpd=sen;
% temp=1;
% for t=sen_unique
%     sneUpd(sen==t)=temp;
%     temp=temp+1;
% end
% B=zeros(mS,v);
% for t=1:v-1
%     temp=(senUpd==t);
%     B(temp,t)=1;
%     groupsize=sum(temp);
%     B(:,t)=B(:,t)-groupsize/mS;
% end
% %------------construct B----------------------
% 
% [Lap D]=lapMatrix(S_t);
% Q=null(B');
% Z=sqrtm(Q'*D*Q);
% invZ=inv(Z);
% 
% forU=invZ'*Q'*Lap*Q*invZ;
% forU=(forU+forU')/2;
% 
% [U,firstkLambda]=firstkEigenvector(forU,parameter.c);
% 
% R_t=Q*invZ*U;

R_t=R_0;

t=1;
while t<parameter.iter+1
    derR=parameter.gamma5*Lap*R_t; % derivative of R
    R_t=R_t-parameter.eta*derR;
    t=t+1;
end
R_tp1=R_t;


