function W_tp1=update_W(W_0,S_t,L_t,parameter) % calculate W
[mS nS]=size(S_t);
[Lap D]=lapMatrix(S_t);

W_t=W_0;
t=1;
while t<parameter.iter+1
    derW=(parameter.gamma2*S_t*S_t'+parameter.gamma3*eye(mS))*W_t-parameter.gamma2*S_t*L_t'; % derivative of W
    W_t=W_t-parameter.eta*derW;
    t=t+1;
end

W_tp1=W_t;