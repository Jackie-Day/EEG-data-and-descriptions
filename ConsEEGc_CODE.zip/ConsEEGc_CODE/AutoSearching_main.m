close all;
clear all;
clc;

load data;
L_true=data(:,1);
[mD nD]=size(data);

%parameter.k=10;% the number of k smallest eigenvalues
parameter.c=2; % number of clusters
parameter.v=2; % number of EEG categories
parameter.nlabel=floor(0.0*mD); % random setting for number of labeled EEG signals
parameter.iter=50; % the number of internal iterations
parameter.eta=0.01; % learning rate
parameter.epsilon=0.01; % internal convergence parameter

L_true=L_true(parameter.nlabel+1:end,:)';  % true labels without labled EEG    
% l_true_matrix=l_true_reshape(L_true,parameter.c)';

Result=[];
GL_0=[];
GS_0=[];
GW_0=[];
GR_0=[];

%Unsupervised Shapelets Learning Algorithm
for parameter_sigma=10.^[-3 -2 -1 0 1 2 3] % parameter in RBF kernel
    parameter.sigma=parameter_sigma;
    for parameter_gamma_1=10.^[-3 -2 -1 0 1 2 3] % regularization parameter
        parameter.gamma1=parameter_gamma_1;
        for parameter_gamma_2=10.^[-3 -2 -1 0 1 2 3] % regularization parameter
            parameter.gamma2=parameter_gamma_2;
            for parameter_gamma_3=10.^[-3 -2 -1 0 1 2 3] % regularization parameter
                parameter.gamma3=parameter_gamma_3;
                for parameter_gamma_4=10.^[-3 -2 -1 0 1 2 3] % regularization parameter
                    parameter.gamma4=parameter_gamma_4;
                    for parameter_gamma_5=10.^[-3 -2 -1 0 1 2 3]
                        parameter.gamma5=parameter_gamma_5;
                        [R_opt, W_opt, L_opt, S_opt,R_0, W_0, L_0, S_0, F_t,F_tp1,wh_time]=ConsEEGc(data,parameter);
                       time=toc; % time record
                       L_opt=L_opt(:,parameter.nlabel+1:end); % clustered labels with unlabled EEG
                       L_pre=reshape_L_opt(L_opt);
                       Result=[Result; NMI ARI kappa fscore time parameter.sigma parameter.gamma1 parameter.gamma2 parameter.gamma3 parameter.gamma4 parameter.gamma5];
                       GL_0=[GL_0;L_0];
                       GS_0=[GS_0;S_0];
                       GW_0=[GW_0;W_0];
                       GR_0=[GR_0;R_0];
                    end
                end
            end
        end
    end
end


