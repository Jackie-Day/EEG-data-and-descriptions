function L_pre=reshape_L_opt(L_opt)
[mL nL]=size(L_opt);

for i=1:mL
%     index(find(L_opt(i,:)==0))=i;
    index(find(L_opt(i,:)==1))=i;
end
L_pre=index;