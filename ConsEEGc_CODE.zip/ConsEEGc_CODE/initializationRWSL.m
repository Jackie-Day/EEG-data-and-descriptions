% initialization for R_0, W_0, S_0, L_0

function [R_0, W_0, S_0, L_0, M]=initializationRWSL(data,parameter)

data_label=data(1:parameter.nlabel,:);
data_unlabel=data(parameter.nlabel+1:end,2:end);

L_label=data_label(1:parameter.nlabel,1);


[mD nD]=size(data(:,2:end));
[L_M D_M M]=GauSimilarity(data(:,2:end),1); % calculate Gaussian similarity of EEG signals

%---------------------------------initialize S0----------------------------------------------
numL=parameter.nlabel;

S_0=1/mD*ones(mD);
for i=1:numL
    for j=1:numL
        if L_label(i)==L_label(j)
            S_0(i,j)=1;
            S_0(j,i)=1;
        else if L_label(i)~=L_label(j)
            S_0(i,j)=0;
            S_0(j,i)=0;
            end
        end
    end
end

for i=1:numL
    S_0(i,:)=S_0(i,:)/sum(S_0(i,:)); % S*1^T=1;
end

%---------------------------------initialize L0----------------------------------------------
[L_unlabel Centroid]=kmeans(data_unlabel,parameter.c); 
L_ini=[L_label;L_unlabel];
L_0=reshape_L_0(L_ini,parameter.c);

%---------------------------------initialize W0----------------------------------------------
W_0=(L_0*inv(M))';

%---------------------------------initialize R0----------------------------------------------
sen=zeros(mD,1);

% a=numel(find(data(:,1))==1);
% b=numel(find(data(:,1))==1);
% fairness=min([a/b b/a]);

for t=1:parameter.c
    for j=1:parameter.v
        sen((mD/parameter.c*(t-1)+mD/(parameter.c*parameter.v)*(j-1)+1):(mD/parameter.c*(t-1)+mD/(parameter.c*parameter.v)*j))=j;
    end
end

sen_unique=unique(sen);
v=length(sen_unique);
sen_unique=reshape(sen_unique,[1, v]);
senUpd=sen;
temp=1;
for t=sen_unique
    sneUpd(sen==t)=temp;
    temp=temp+1;
end
B=zeros(mD,v);
for t=1:v-1
    temp=(senUpd==t);
    B(temp,t)=1;
    groupsize=sum(temp);
    B(:,t)=B(:,t)-groupsize/mD;
end

%[D Lap]=lapMatrix(M);
Q=null(B');
Z=sqrtm(Q'*D_M*Q);
invZ=inv(Z);

forU=invZ'*Q'*L_M*Q*invZ;
forU=(forU+forU')/2;

[U,firstkLambda]=firstkEigenvector(forU,parameter.c);

R_0=Q*invZ*U;

