function [D_S_tp1 S_tp1]=update_S(M,S_0,W_t,R_t,L_t,L_label,parameter)

S_t=S_0;
[mS nS]=size(S_t);
[Lap D]=lapMatrix(S_t);
[numL colL]=size(L_label);
t=1;
while t<parameter.iter+1
    P1=(parameter.gamma1*eye(mS)+parameter.gamma2*W_t*W_t')*S_t;
    P2=parameter.gamma1*M+parameter.gamma2*W_t*L_t;
    P3=0.5*parameter.gamma4*L_t'*L_t+0.5*parameter.gamma5*R_t*R_t';
    derS=P1-P2-P3; % derivative of S
    S_t=S_t-parameter.eta*derS;
    for i=1:mS
        for j=1:mS
            if S_t(i,j)<=0
                S_t(i,j)=0;
            end
        end
    end

    for i=1:parameter.nlabel
        for j=1:parameter.nlabel
            if L_label(i)==L_label(j)
                S_t(i,j)=1;
                S_t(j,i)=1;
            else if L_label(i)~=L_label(j)
                    S_t(i,j)=0;
                    S_t(j,i)=0;
                end
            end
        end
    end
    for i=1:mS
        S_t(i,:)=S_t(i,:)/sum(S_t(i,:)); % S*1^T=1;
    end
    [L_S_t D_S_t]=lapMatrix(S_t);
    t=t+1;
end

S_tp1=S_t;
D_S_tp1=D_S_t;


